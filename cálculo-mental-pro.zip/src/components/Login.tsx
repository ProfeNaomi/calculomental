import React, { useState, useEffect } from 'react';
import { LogIn } from 'lucide-react';

export function Login({ onLogin }: { onLogin: (name: string) => void }) {
  const [name, setName] = useState('');

  useEffect(() => {
    const storedName = localStorage.getItem('mentalMathUserName');
    if (storedName) {
      setName(storedName);
    }
  }, []);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (name.trim()) {
      localStorage.setItem('mentalMathUserName', name.trim());
      onLogin(name.trim());
    }
  };

  return (
    <div className="flex-1 flex flex-col items-center justify-center p-4">
      <div className="bg-white/90 backdrop-blur-xl border border-stone-200 p-10 rounded-3xl shadow-2xl w-full max-w-md text-center">
        <h1 className="text-4xl md:text-5xl font-black text-stone-800 mb-2 tracking-tight drop-shadow-sm">
          Cálculo Mental <span className="text-pink-500">Pro</span>
        </h1>
        <p className="text-stone-600 mb-8 text-sm">
          Ingresa para guardar tu progreso<br/>
          <span className="text-xs opacity-70">(Próximamente ingreso con Google)</span>
        </p>
        
        <form onSubmit={handleSubmit} className="flex flex-col gap-4">
          <input
            type="text"
            value={name}
            onChange={(e) => setName(e.target.value)}
            placeholder="Tu nombre..."
            className="px-4 py-4 rounded-xl bg-stone-100 border border-stone-300 text-stone-800 placeholder-stone-400 focus:outline-none focus:ring-2 focus:ring-pink-400 text-xl font-semibold text-center shadow-inner"
            required
            maxLength={20}
          />
          <button 
            type="submit" 
            className="bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-4 rounded-xl shadow-lg transform hover:scale-105 transition-all flex items-center justify-center gap-2 text-lg"
          >
            <LogIn size={24} /> Entrar al Mapa
          </button>
        </form>
      </div>
    </div>
  );
}
